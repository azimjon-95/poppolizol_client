// Polizol va Folygoizol uchun massiv
export const polizolFolygoizol = [
    "Polizol 0.5 mm",
    "Polizol 1 mm",
    "Polizol 1.5 mm",
    "Polizol 2 mm",
    "Polizol 2.5 mm",
    "Polizol 3 mm",
    "Polizol 4 mm",
    "Polizol (Brak)",

    "Folygoizol 1 mm",
    "Folygoizol 2 mm",
    "Folygoizol 2.5 mm",
    "Folygoizol 3 mm",
    "Folygoizol 4 mm",
    "Folygoizol (Brak)"
];

// Ruberoid uchun massiv
export const ruberoid = [
    "Ruberoid RKP-250 9m (Yupqa)",
    "Ruberoid RKP-250 10m (Yupqa)",
    "Ruberoid RKP-250 15m (Yupqa)",
    "Ruberoid RKP-300 9m (O‘rta)",
    "Ruberoid RKP-300 15m (O‘rta)",
    "Ruberoid RKP-350 10m (Qalin)",
    "Ruberoid RKP-350 15m (Qalin)",
    "Ruberoid (Brak)"
];